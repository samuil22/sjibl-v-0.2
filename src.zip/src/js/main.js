// $(document).ready(function(){
//     $(".hov_btn2").click(function(){
//        $('.hover_three').toggleClass('width_100');console.log("hi");
//     });
//    $(".hov_btn1").click(function(){
//      $('.hover_two').toggleClass('width_100');
     
//     });
//     $(".hov_btn2").click(function(){
//        $('.hover_three').toggleClass('width_100');
//     });
// });
